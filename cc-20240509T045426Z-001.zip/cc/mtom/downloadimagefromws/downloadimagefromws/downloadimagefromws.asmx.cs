﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.ComponentModel;

namespace downloadimagefromws
{
    /// <summary>
    /// Summary description for downloadimagefromws
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class downloadimagefromws : System.Web.Services.WebService
    {

        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }
        [WebMethod, Description("Get Image Content")]
        //This code is binary MTOM, We are use byte[] becuse that our data is binary formate 
        //Method name is GetImageFile() (As per your choice name)
        public byte[] GetImageFile(string fileName)
        {
            //IF file is exists then this file downlode in server
            if (System.IO.File.Exists(Server.MapPath("~/Images/") + fileName))
            {
                //If file is exists then it is downlode and return the file
                return System.IO.File.ReadAllBytes(Server.MapPath("~/Images/") + fileName);
            }
            else
            {
                return new byte[] { 0 };
            }
        }
    }
}

