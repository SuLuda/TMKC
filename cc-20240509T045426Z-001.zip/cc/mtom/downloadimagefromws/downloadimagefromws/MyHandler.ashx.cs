﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace downloadimagefromws
{
    /// <summary>
    /// Summary description for $codebehindclassname$
    /// </summary>
   // [WebService(Namespace = "http://tempuri.org/")]
   // [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class MyHandler : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            //Create a Object
            downloadimagefromws ws = new downloadimagefromws();
            byte[] binImage = ws.GetImageFile(context.Request["fileName"]);
            if (binImage.Length == 1)
            {
                //do nothing
            }
            else
            {
                context.Response.ContentType = "image/jpeg";
                context.Response.BinaryWrite(binImage);
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}
