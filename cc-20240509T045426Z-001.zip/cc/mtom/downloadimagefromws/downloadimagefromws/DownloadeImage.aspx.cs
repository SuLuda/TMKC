﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace downloadimagefromws
{
    public partial class DownloadeImage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn1_Click(object sender, EventArgs e)
        {
            //Display the image from server
            Image1.ImageUrl = "~/MyHandler.ashx?fileName=" + txt1.Text;
            Response.Write("Downloding of Image is Done");
        }
    }
}
