import java.util.Scanner;

public class ccPRAC1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        try {
            System.out.println("Please enter dollars:");
            double dollars = scanner.nextDouble();
            double rupees = dollars * 83;
            System.out.println(rupees + " Rupees");
        } catch (Exception e) {
            System.out.println("Invalid input. Please enter a valid number.");
        } finally {
            scanner.close();
        }
    }
}
