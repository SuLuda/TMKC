using System;

class MainClass
{
    public static void Main(string[] args)
    {
        try
        {
            Console.WriteLine("Please enter dollars:");
            double dollars = Convert.ToDouble(Console.ReadLine());
            double rupees = dollars * 83;
            Console.WriteLine(rupees + " Rupees");
        }
        catch (FormatException)
        {
            Console.WriteLine("Invalid input. Please enter a valid number.");
        }
        Console.ReadKey();
    }
}
